DROP DATABASE `new_cd40_trans`;
DROP DATABASE `new_cd40`;
CREATE DATABASE  `new_cd40_trans`;
CREATE DATABASE  `new_cd40`;