
show master status\G;