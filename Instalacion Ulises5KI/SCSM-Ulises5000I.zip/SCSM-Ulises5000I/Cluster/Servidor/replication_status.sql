
show global status like 'slave_running';